﻿function openModal(){
    document.getElementById('myModal').style.display = "block";
}
function closeModal(){
  document.getElementById('myModal').style.display = "none";
}

function openModal2(){
    document.getElementById('myModal_2').style.display = "block";
}
function closeModal2(){
  document.getElementById('myModal_2').style.display = "none";
}

function openModal3(){
    document.getElementById('myModal_3').style.display = "block";
}
function closeModal3(){
  document.getElementById('myModal_3').style.display = "none";
}
